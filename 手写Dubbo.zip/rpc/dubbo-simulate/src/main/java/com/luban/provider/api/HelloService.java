package com.luban.provider.api;

public interface HelloService {

    String sayHello(String userName);
}
