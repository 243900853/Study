package com.luban.config;

import org.springframework.stereotype.Component;

@Component
public class NotVeryUsefulAspect {
}
