package com.luban.init;

import com.luban.config.AppConfig;
import com.luban.service.WebInit;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;

/**
 * 需要咨询JAVA高级VIP课程的可以加白浅老师的QQ：2207192173
 * 需要视频资料或者咨询课程的可以加若曦老师的QQ：2408349392
 * author：鲁班学院-商鞅老师
 */
public class MyWebApplicationInitializer implements WebApplicationInitializer {


    //0配置原理
    //servlet 3.0 SPI规范
    //AppConfig
    //内嵌Tomcat
    //自己实现SPI..
    // 为什么 spring boot  能解析 非 web app 目录下的资源


    //实现0xml
    //写一个类 实现spring 的接口：WebApplicationInitializer


    //tomcat 启动的时候会调用 onStartup方法 为什么？

    //传入一个ServletContext ： web上下文对象   web.xml能做的 ServletContext都能做
    //因为servlet 3.0的一个新规范   为什么不是tomcat规范而是servlet规范
    //SPI “你”
    @Override
    public void onStartup(ServletContext servletCxt) {
        //初始化spring 容器  以注解的方式
        AnnotationConfigWebApplicationContext ac = new AnnotationConfigWebApplicationContext();
        ac.register(AppConfig.class);
        ac.setServletContext(servletCxt);
        ac.refresh();
        //A a = new A();
        //re
        //B b =new B(a);

        //A就是B的父容器   默认如果你没有自己写逻辑去控制的话 那么通过B容器去找一个对象的时候 他会尝试去A(父)容器里面去找...
        //spring mvc 做了 现在是直接默认不去父容器找 直接去子容器
//        ClassPathXmlApplicationContext
        DispatcherServlet servlet = new DispatcherServlet(ac);
        ///Spring 和Spring mvc 是2个不同的容器
        //application.xml  application-mvc.xml
        ServletRegistration.Dynamic registration = servletCxt.addServlet("app", servlet);
        registration.setLoadOnStartup(1);
        registration.setInitParameter("contextConfigLocation","classpath:");
        registration.addMapping("*.do");
}
}