package com.luban.config;

import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.luban.arg.ArgamentResovel;
import com.luban.cotroller.TestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.validation.MessageCodesResolver;
import org.springframework.validation.Validator;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * 需要咨询JAVA高级VIP课程的可以加白浅老师的QQ：2207192173
 * 需要视频资料或者咨询课程的可以加若曦老师的QQ：2408349392
 * author：鲁班学院-商鞅老师
 */
@Configuration
@ComponentScan("com")
//@EnableAspectJAutoProxy
//@EnableWebMvc  // <annotation:driver>
public class AppConfig extends WebMvcConfigurationSupport  {



    @Autowired//Spring mvc 环境初始化完之后 去加载这个方法
    public void initArgumentResolvers(   RequestMappingHandlerAdapter requestMappingHandlerAdapter){
        List<HandlerMethodArgumentResolver> argumentResolvers = new ArrayList<>(requestMappingHandlerAdapter.getArgumentResolvers());
        List<HandlerMethodArgumentResolver> customResolvers = requestMappingHandlerAdapter.getCustomArgumentResolvers();
        argumentResolvers.removeAll(customResolvers);
        argumentResolvers.addAll(0, customResolvers);
        requestMappingHandlerAdapter.setArgumentResolvers(argumentResolvers);
    }
//
//    @Bean //不行  因为这时候spring mvc 容器还没有初始化完成  这时候会报错 说没有RequestMappingHandlerAdapter
//    public void initArgumentResolvers1(   RequestMappingHandlerAdapter requestMappingHandlerAdapter){
//        List<HandlerMethodArgumentResolver> argumentResolvers = new ArrayList<>(requestMappingHandlerAdapter.getArgumentResolvers());
//        List<HandlerMethodArgumentResolver> customResolvers = requestMappingHandlerAdapter.getCustomArgumentResolvers();
//        argumentResolvers.removeAll(customResolvers);
//        argumentResolvers.addAll(0, customResolvers);
//        requestMappingHandlerAdapter.setArgumentResolvers(argumentResolvers);
//    }



    //这接口里面的方法贯穿了所有spring mvc的配置

//    @Bean

//    @Override
//    public void configurePathMatch(PathMatchConfigurer configurer) {
//
//    }
//
//    @Override
//    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
//
//    }
//
//    @Override
//    public void configureAsyncSupport(AsyncSupportConfigurer configurer) {
//
//    }
//
//    @Override
//    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
//
//    }
//
//    @Override
//    public void addFormatters(FormatterRegistry registry) {
//
//    }
//
//    @Override
//    public void addInterceptors(InterceptorRegistry registry) {
//
//    }
//
//    @Override
//    public void addResourceHandlers(ResourceHandlerRegistry registry) {
//
//    }
//
//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//
//    }
//
//    @Override
//    public void addViewControllers(ViewControllerRegistry registry) {
//
//    }
//
//    /**
//     * 在这里配置视图解析器
//     * @param registry
//     */
    @Override
    public void configureViewResolvers(ViewResolverRegistry registry) {
        registry.jsp("/page/",".html");
    }
//



    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
        //resolvers 和spring mvc 里面用 resolvers 不是同一个集合  比如spring mvc 里面用的是
        //A.addAll(resolvers)
        resolvers.add(0,new ArgamentResovel());
    }
//
//    @Override
//    public void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> handlers) {
//        handlers.add(MyXXX);
//    }
//
    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
//        for (HttpMessageConverter<?> converter : converters) {
//            System.out.println(converter);
//        }
        FastJsonHttpMessageConverter fastJsonHttpMessageConverter
                = new FastJsonHttpMessageConverter();
        converters.add(fastJsonHttpMessageConverter);
    }
//
//    @Override
//    public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
//
//    }
//
//    @Override
//    public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> resolvers) {
//
//    }
//
//    @Override
//    public void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> resolvers) {
//
//    }
//
//    @Override
//    public Validator getValidator() {
//        return null;
//    }
//
//    @Override
//    public MessageCodesResolver getMessageCodesResolver() {
//        return null;
//    }




//    @Bean
//    public TestController user(){
//         return  new TestController();
//    }



}
