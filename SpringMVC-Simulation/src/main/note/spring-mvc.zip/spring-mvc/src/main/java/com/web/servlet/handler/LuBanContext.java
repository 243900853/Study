//package com.web.servlet.handler;
//
//import org.springframework.beans.BeansException;
//import org.springframework.beans.factory.support.GenericBeanDefinition;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.GenericApplicationContext;
//import org.springframework.context.support.StaticMessageSource;
//import org.springframework.lang.Nullable;
//
//public class LuBanContext extends GenericApplicationContext
//{
//
//    //判断spring 容器有没有执行过refresh这个方法
//    //但是我们测试不需要判断 所以直接覆写他的逻辑 不让他报错
//    public  void assertBeanFactoryActive(){
//
//    }
//
//    public LuBanContext() throws BeansException {
//        this(null);
//    }
//
//    /**
//     * Create a new StaticApplicationContext with the given parent.
//     * @see #registerBeanDefinition
//     * @see #refresh
//     */
//    public LuBanContext(@Nullable ApplicationContext parent) throws BeansException {
//        super(parent);
//
//    }
//
//
//    public void registerSingleton(String name, Class<?> clazz) throws BeansException {
//        GenericBeanDefinition bd = new GenericBeanDefinition();
//        bd.setBeanClass(clazz);
//        getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
//    }
//
//}
