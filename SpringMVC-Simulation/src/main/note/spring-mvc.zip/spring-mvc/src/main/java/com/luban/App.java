//package com.luban;
//
////import org.apache.catalina.Context;
////import org.apache.catalina.LifecycleException;
////import org.apache.catalina.LifecycleListener;
////import org.apache.catalina.startup.Tomcat;
//import org.apache.catalina.Context;
//import org.apache.catalina.LifecycleListener;
//import org.apache.catalina.servlets.DefaultServlet;
//import org.apache.catalina.startup.Tomcat;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//
//public class App {
//
//    public static void main(String[] args) throws Exception {
//        Tomcat tomcat = new Tomcat();
//        tomcat.setPort(80);
//        //
//        System.out.println(App.class.getResource("/"));
//        Context context = tomcat.addContext("/", App.class.getResource("/").getPath().replaceAll("%20"," "));
//        //只会去初始化一个 context的资源目录 并不会加载 web的生命周期
//        // webapps
//        // .war   文件夹
////                tomcat.addWebapp("/",App.class.getResource("/").getPath().replaceAll("%20"," "));
////        context.adds
//        tomcat.addServlet(context,"default",new DefaultServlet());
//        context.addServletMappingDecoded("/*","default");
//        context.addLifecycleListener((LifecycleListener) Class.forName(tomcat.getHost().getConfigClass()).newInstance());
//        tomcat.start();
//
//        tomcat.getServer().await();
//
//        //传一个xml文件进去
////        ClassPathXmlApplicationContext
////                classPathXmlApplicationContext = new ClassPathXmlApplicationContext();
//
//
//    }
//}
