package com.luban.service;

import javax.servlet.ServletContext;

public interface WebInit {


    void start(ServletContext context);

}
