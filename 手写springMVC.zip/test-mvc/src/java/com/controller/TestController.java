package com.controller;

import com.annotation.Controller;
import com.annotation.RequestMapping;
import com.annotation.ResponseBody;
import com.entity.UserEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 需要咨询JAVA高级VIP课程的可以加若曦老师：2408349392
 * 需要视频资料或者咨询课程的可以加安其拉老师：2246092212
 * author：鲁班学院-商鞅老师
 */

@Controller
@RequestMapping("/test")
public class TestController {

    //  localhost:8080/test/test.do
    @RequestMapping("/test.do")
    //name request response entity
    //arg0 arg1 arg2 arg3
    public String test(String name, HttpServletRequest request, HttpServletResponse response, UserEntity entity){
        System.out.println(name);
        System.out.println(request);
        System.out.println(response);
        System.out.println(entity);
        System.out.println("调用了");
        return "/index";
    }

    @RequestMapping("/respond.do")
    @ResponseBody
    public Object respond(){

        return "test";
    }

}
